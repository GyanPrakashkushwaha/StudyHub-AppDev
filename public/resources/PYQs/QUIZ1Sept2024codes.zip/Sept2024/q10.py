from flask import Flask, request
import sys
app = Flask(__name__)

@app.route('/home', methods = sys.argv[1:]) #['app.py', 'GET', "POST"]
def my_func():
    print(sys.argv[1:])
    if request.method == 'GET':
        return "<h1>Hello from POST</h1>"

    elif request.method == 'POST':
        return "<h1>Hello from GET</h1>"

    else:
        return "<h1>Please enter a valid HTTP method<h1>"

app.run(debug = True)
#curl http://127.0.0.1:5000/home