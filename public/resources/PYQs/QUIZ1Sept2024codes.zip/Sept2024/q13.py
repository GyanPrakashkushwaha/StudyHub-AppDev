from flask import Flask

app = Flask(__name__)

@app.route("/<id>")
def get_employee(id):
    return "Employee id : " + str(id)

if __name__ == "__main__":
    print(help(app.route))
    app.run(debug=True)