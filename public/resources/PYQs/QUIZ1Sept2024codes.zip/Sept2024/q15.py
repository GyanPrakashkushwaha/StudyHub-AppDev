from flask import Flask
from flask import render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "GET":
        return render_template("form.html")
    else:
        return render_template("home.html")

app.run(debug=True)
# http://127.0.0.1:5000/?name=Application