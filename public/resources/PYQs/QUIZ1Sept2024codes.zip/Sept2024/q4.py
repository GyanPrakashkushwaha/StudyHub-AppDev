from string import Template

template='''
Welcome to $Degree DEGREE
First level to clear is $level
'''

rendered=Template(template)
output=rendered.safe_substitute(Degree="IITM BS",level="Foundation")
print(output)