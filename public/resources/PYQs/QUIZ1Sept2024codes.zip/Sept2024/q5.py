#curl -v https://www.google.com/search?q=physics+books
from string import Template
greet_template = Template('Hello, $name! Welcome to $place.')

data = dict(name='Bob')

# greeting3 = greet_template.substitute(data)
# print(greeting3)
greeting1 = greet_template.substitute(name='Alice', place='Wonderland')
print(greeting1)

greeting2 = greet_template.safe_substitute(data)
print(greeting2)

