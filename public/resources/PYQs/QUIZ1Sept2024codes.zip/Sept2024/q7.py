from jinja2 import Template

class Loan:

    def __init__(self, accno, loan_amount, interest_rate):
        self.accno = accno
        self.loan_amount = loan_amount
        self.interest_rate = interest_rate

    def get_loan_details(self):
        return (self.accno, self.loan_amount, self.interest_rate)

loan1 = Loan(101, 45900, 5)
loan2 = (102, 170000, 6)

tm1=Template("Account1:{{var1.get_loan_details()}}") # Loan class
tm2= Template("Account2:{{var2}}") # tuple

print(tm1.render(var1=loan1))
print(tm2.render(var2=loan2))