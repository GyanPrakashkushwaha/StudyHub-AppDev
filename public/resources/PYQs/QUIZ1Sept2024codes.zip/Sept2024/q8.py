from flask import Flask
app = Flask(__name__)
@app.route('/communication/<type>/<int:areacode>')
def home(type, areacode):
    details = {'type': type, 'area-code': areacode}
    return details


# @app.route('/communication/<string:type>/<int:areacode>')
# def home(type, areacode):
#     details = {'type': type, 'area-code': areacode}
#     return details



# @app.route('/communication/<string:type>/0712')
# def home(type):
#     details = {'type': type, 'area-code': 44}
#     return details

# http://127.0.0.1:5000/communication/landline/0712

# @app.route('/communication/online/<string:type>/<areacode>')
# def home(type, areacode):
#     details = {'type': type, 'area-code': int(areacode)}
#     return details

if __name__ == "__main__":
    app.run(debug=True)