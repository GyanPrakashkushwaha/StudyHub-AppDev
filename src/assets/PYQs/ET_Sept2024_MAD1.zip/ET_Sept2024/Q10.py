from flask import Flask, request, session, abort

app = Flask(__name__)
app.config['SECRET_KEY'] = "yekterces"

@app.route('/login')
def log_in():
    user = request.args['user'] #?user= admin
    role = request.args['role'] if 'role' in request.args else 'general' #?role=
    session['user'], session['role'] = user, role # Temporary dictionary (COOKIE)
    print(user, role) # {'user': "admin", "role": "general"}
    return "Logged in successfully!"

@app.route('/home')
def land():
    print(session)
    if 'user' in session: # if user key is there in session dictionary
        if session['role'] == 'admin':
            return f"Welcome {session['user' ]}" 
        return abort(401)
    return abort(404)

@app.route('/logout')
def log_out():
    session.pop('user', None) # {"user":}
    session.pop('role', None) # {"role": }
    print(session)
    return "Logged out sucessfully!"

app.run(debug=True)