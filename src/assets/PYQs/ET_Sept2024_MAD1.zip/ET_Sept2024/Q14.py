import logging
import sys

logging.basicConfig(level=logging.WARNING, format='%(asctime)s -%(levelname)s -%(message)s')

def check_val(value):
    if value < 0:
        raise ValueError("Invalid value: Please enter a positive value.")
    else:
        logging.info("Value added: %s", value) # INFO lower priority than WARNING

try:
    input_value = -int(sys.argv[1]) #-int("-12") = 12
    print(sys.argv)
    check_val(input_value)
except ValueError as ve:
    logging.exception("Exception occurred: %s", str(ve))