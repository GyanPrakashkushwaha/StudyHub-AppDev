from flask_sqlalchemy import SQLAlchemy
from flask import Flask

app = Flask (__name__)
app.config ['SQLALCHEMY_DATABASE_URI' ] = 'sqlite:///testdb.sqlite3'
db = SQLAlchemy(app)
app.app_context().push()

class Material(db.Model):
    m_id = db.Column('m_id', db.Integer, primary_key = True)
    name = db.Column('name', db.String(100), unique = True)

db.create_all() # create all the DB tables
material1 = Material(name = 'Steel')
db.session.add(material1) # m_id = 1; name = Steel
material2 = Material(name = 'Iron')
material3 = Material(name = 'Aluminium')
db.session.add(material2) # m_id = 2; name = Iron
db.session.commit() # Steel Iron in testdb.
db.session.add(material3) # m_id = 3; name = Aluminium

all_material = Material.query.all() # session
print(all_material)
print([(x.m_id, x.name) for x in all_material])