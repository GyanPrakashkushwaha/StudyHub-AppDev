from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html", data=['Harry', 'Karl', 'John', 'Jason', 'Ros'])

app.run()
