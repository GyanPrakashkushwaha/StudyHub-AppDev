import sys
from jinja2 import Template
vars = sys.argv # ["code.py", ]
print(vars)
course_technologies = {'python': 'backend', 'javascript': 'frontend'}
template = Template("This course focuses on {{ technology }} development.")

if len(vars) > 2 and vars[2] in course_technologies: # keys of dictionary 
    course = vars[1]
    technology = course_technologies[course] # VALUE for course key
    print(template.render(technology=technology))
else:
    print("Please specify a valid course name!")