from flask import Flask, abort, request
app = Flask(__name__)

data = {"CS2001":"DBMS","CS2003":"MAD-I","CS2006":"MAD-II"}
@app.route('/login')
def login():
    username = request.args.get('uname') # ?uname= URL QUERY STRING
    print(username)
    if username not in data: # not in dictionary not in dictionary.keys() CHECKING KEY is in DICTIONARY
        abort(400, "Bad Request: Invalid Username")
    return f'<h1>Welcome to {data[username]} course !< /h1>' # value

app.run(debug=True)