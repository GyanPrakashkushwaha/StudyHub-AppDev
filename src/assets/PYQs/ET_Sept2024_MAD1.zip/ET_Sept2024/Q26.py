from flask import Flask, request
app = Flask(__name__)

@app.route('/home', methods=["POST"])
def home():
    var_a = request.args.get('method')
    if var_a == "GET":
        return "Hello from GET method"

    elif var_a == "POST":
        return "Hello from POST method"

    else:
        return "Invalid Method"

app.run(debug=True)