from flask_sqlalchemy import SQLAlchemy
from flask import Flask

app = Flask (__name__)
app.config ['SQLALCHEMY_DATABASE_URI' ] = 'sqlite:///testdb.sqlite3'
db = SQLAlchemy(app)
app.app_context().push()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username= db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)
    email= db.Column(db.String())
    roles= db.relationship("Role", backref="bearer")

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    r_name = db.Column(db.String(), unique=True, nullable=False)
    user = db.Column(db.Integer, db.ForeignKey("user.id"))

# db.create_all()
# user1 = User(username="Rakesh",password="1234",email="user1@gmail.com")
# user2 = User(username="Suresh", password="123", email="user2@gmail.com")
# db.session.add_all([user1,user2])
# db.session.commit()
# r1=Role(r_name="instructor",user=1)
# r2=Role(r_name="admin",user=1)
# r3=Role(r_name="ops",user=2)
# r4=Role(r_name="student",user=2)
# db.session.add_all([r1,r2,r3,r4])
# db.session.commit()
users = User.query.all()
roles = Role.query.all()
# print(roles)
# print(roles[2])
# u1 = users[1]
# print(u1.roles) # [instructor , admin]
# print(roles[3].user)
# print(roles[3].user)
print(roles[0].bearer)
