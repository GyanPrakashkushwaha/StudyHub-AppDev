from flask import Flask, abort
app = Flask(__name__)
modules = ['python', 'react', 'node' ]

@app.route('/home/modules/')
def all_modules():
    return f"<h3>List of modules: {modules}</h3>"

@app.route('/get/<string:module_1>')
def get_module(module_1):
    if module_1 in modules:
        return f"<h3>One module found: {module_1} .< /h3>"
    else:
        abort(400)

# @app.errorhandler(400)
# def module_error(error):
#     return "<h3>Cannot find module</h3>"

@app.errorhandler(404)
def module_error(error):
    return "<h3>Incorrect Path</h3>"

app.run(debug=True)