from flask import Flask, request
import sys
app = Flask(__name__)
data = ["Java", "Application Development","DBMS"]

@app.route('/course') #?course=
def home():
    course = request.args.get('course')
    if course in sys.argv[1]: # URL parameter course = 1st index on termial
        # print(sys.argv) # if "Application" in "Application Development"
        if sys.argv[1] in data: #1st index on termial is in ["Java", "Application Development","DBMS"]
            return f"Welcome to {sys.argv[1]}!"
        return f"Welcome to {course}!"
    else:
        return "Invalid Data"

# python app.py "Application Development"
# /course?course="Application Development" python app.py "Application Development"
app.run(debug=True)

# "Application development" in "Application Development"
