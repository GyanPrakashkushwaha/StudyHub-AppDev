from flask import Flask, request
app = Flask(__name__)

@app.route('/calculate')
def calculate():
    a = request.args.get('a') # ?a="4"
    b = request.args.get('b')# ?b="2"
    operator = request.args.get('operator') #?operator=""
    if a and b and operator:
        if operator == 'one':
            return f'{a} + {b} = {a+b}' #"4" + "2"
        elif operator == 'two':
            return f'{a} - {b} = {int(a) - int(b)}' # 2
        elif operator == 'three':
            return f'{a} x {b} = {int(a)*b}' # 4*"2" = "2222"
    else:
        return 'Error: Insufficient arguments'
app.run(debug=True)


