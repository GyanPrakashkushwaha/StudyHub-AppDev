from flask import Flask, request
from flask_restful import Api, Resource, reqparse

app = Flask(__name__)
api = Api(app)

parser = reqparse.RequestParser() # VALIDATOR
parser.add_argument("val") # keys or arguments

#@app.route("/api/courses/<val>")
#if request.method == 'POST'
class RestApi(Resource): # class = API resource 
    def post(self, val):
        arg1 = parser.parse_args() # RESPONSE BODY -d
        arg2 = request.args #?val=  DICTIONARY URL PARAMETER
        print(arg1) # {"val" : "PDSA"}
        print(arg2) # {val : JAVA}
        return {
        "Course_1": arg1["val"],
        "Course_2": arg2["val"],
        "Course_3": val # DBMS
        }

api.add_resource(RestApi, "/api/courses/<val>") # register App routes
app.run(debug = True)