from jinja2 import Template
# from string import Template # $
import sys
input_list = sys.argv # takes argument from python app.py[0] Radha [1]
print(f"sys.argv: {input_list}")
var_a, var_b = input_list[1], input_list[2]

if input_list[1] == "Meera":
    var_b = "Data Analyst"
elif input_list[1] == "Radha":
    var_b = "Scientist"
else:
    pass

template = "{{var_a}} is {{var_b}}" # {{}} String
t = Template(template)
print(t.render(var_a = var_a, var_b = var_b)) # t.substitute