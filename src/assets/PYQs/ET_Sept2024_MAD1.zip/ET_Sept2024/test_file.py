import pytest
def func(x,y):
    out = x ** 2+y ** 2
    return out

class Test_class0():
    def test_case1(self):
        assert func(1,2) == 5 #pass

    def test2_case(self): # not recognized
        assert func(2,3) == 13 #pass

    def test3_case(self): # not recognized
        assert func(6,2) == 38 #FAIL

class Test_class1():
    def test_case1(self):
        assert func(5,2) == 29 #pass

    def test2_case(self): # not recognized
        assert func(1,1) == 2  #pass