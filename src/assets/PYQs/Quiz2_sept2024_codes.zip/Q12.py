from flask_restful import Api, Resource
from flask import Flask

app = Flask(__name__)
api = Api(app)

class TestApi(Resource):
    def get(self):
    # logic to retrieve data from backend
        return {
        "val1": "value1",
        "val2": "value2",
        "val3": "value3"
        }

    def delete(self, val):
    # logic to delete the value from data w.r.t "val" argument
        return {
        "message": "Value deleted successfully",
        "value": val
        }, 200

    def put(self, val):
    # logic to update the value from data w.r.t "val" argument
        return {
        "message": "Value updated successfully",
        "value": val
    }, 200

api.add_resource(TestApi, '/get_values', '/delete/<val>', '/update/<val>')

app.run()