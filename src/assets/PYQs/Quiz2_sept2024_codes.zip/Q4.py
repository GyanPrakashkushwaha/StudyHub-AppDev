from flask import Flask
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

salaries = {
1: {"name": "Ravi", "basic": 14500},
2: {"name": "David", "basic": 9500},
3: {"name": "Tinu", "basic": 15009},
}
class Salaries(Resource):
    def do_something(self):
        for s in salaries.keys():
            salaries[s]["hra"] = salaries[s]["basic"] * 0.10

    def get(self):
        self.do_something()
        return salaries

api.add_resource(Salaries, "/api/salaries")
app.run(debug=True)