from flask import Flask, abort, request
app = Flask(__name__)

@app.route('/login/<id>')
def login(id):
    if id:
        print(id)
        if id.isalnum():
            abort(400, "Bad Request: Invalid ID")
        return f'<h1>Your ID is: {id}</h1>'
    return f'<h1>Invalid ID</h1>' #not get printed, 404 Not Found if not if id

app.run(debug=True)