from flask import Flask, abort, request

app = Flask(__name__)
data = {'PDSA': 'CS2003', 'DBMS': 'CS2004', 'Java': 'CS2005'}
@app.route('/course/<course_name>')
def course(course_name):
    course_id = request.args.get('id') #?id=101
    print(course_name, course_id)
    if course_name in data and course_id == data[course_name]:
        return f'<h1>The Course ID for {course_name} is: {course_id}</h1>'
    else:
        abort(400, "Bad Request: Invalid data")

app.run(debug=True)
#1. course_name, ?course_id
# a. valid key-value mapping, valid coursename
# b. not valid mapping or coursename