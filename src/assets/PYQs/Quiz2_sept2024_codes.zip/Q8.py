from flask import Flask
import json
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

class Car:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model

    def __str__(self) -> str:
        result = {
        "brand": self.brand,
        "model": self.model,
        }
        return str(result)

class MyApi(Resource):
    def get(self, brand, model):
        c = Car(brand, model)
        return json.dumps(c, default=vars)

api.add_resource(MyApi, "/api/<string:brand>/<string:model>")
app.run(debug=True)